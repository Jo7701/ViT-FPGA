#ifndef __DEIT_H__
#define __DEIT_H__

#include "embedder_matmul.h"
#include "qk_matmul.h"
#include "mha0.h"
#include "softmax.h"
#include "v_matmul.h"

static const int img_size = 224;
static const int patch_size = 16;
static const int num_channels = 3;

void embedder(
		ap_fixed<8,1>* weight_ddr, ap_fixed<8, 4>* bias_ddr, ap_fixed<8, 1>* input,
		ap_fixed<8,1> input_bram[198][768], ap_fixed<8, 4> output_bram[198][768]
);

void mha (
		ap_fixed<8, 4> input_bram[198][768],
		ap_fixed<8, 5> q_proj_bram[12][198][64],
		ap_fixed<8, 5> k_proj_bram[12][198][64],
		ap_fixed<8, 5> v_proj_bram[12][198][64],
		ap_fixed<8, 6> scores_bram[12][198][198],
		ap_fixed<8, 5> output_bram[198][768]
);

#endif
