#include "mha0.h"
#include <stdio.h>

const int TILE_SIZE = 16;

void bram_to_regs(
	ap_fixed<8, 4> input_bram[198][768],
	ap_fixed<8, 4> qinput_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<8, 4> kinput_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<8, 4> vinput_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<8, 1> qweight_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<8, 1> kweight_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<8, 1> vweight_regs[TILE_SIZE][TILE_SIZE],
	int i, int j, int k
) {
	printf("col idx (%d, %d, %d)\n", i, j, k);
	ap_uint<12> qidx = 0, kidx = 0, vidx = 0;
	for(int outer = 0; outer < TILE_SIZE; outer++) {
		for(int inner = 0; inner < TILE_SIZE; inner++) {
#pragma HLS pipeline II=1
			int weight_hidx = i*TILE_SIZE+outer, weight_widx = k*TILE_SIZE+inner;
			int input_widx = j*TILE_SIZE + outer;

			if(weight_hidx < 768 && weight_widx < num_nonzero) {
				qweight_regs[outer][inner] = q_linear_weight[weight_hidx][weight_widx];
				qidx = q_linear_idx[weight_hidx][weight_widx];
				kweight_regs[outer][inner] = k_linear_weight[weight_hidx][weight_widx];
				kidx = k_linear_idx[weight_hidx][weight_widx];
				vweight_regs[outer][inner] = v_linear_weight[weight_hidx][weight_widx];
				vidx = v_linear_idx[weight_hidx][weight_widx];
			}

			printf("%d ", qidx.to_int());

			if(input_widx < 198) {
				qinput_regs[inner][outer] = input_bram[input_widx][qidx];
				kinput_regs[inner][outer] = input_bram[input_widx][kidx];
				vinput_regs[inner][outer] = input_bram[input_widx][vidx];
			}
		}
		printf("\n");
	}

	printf("\nload weights: (%d, %d, %d)\n", i, j, k);
	for(int i = 0; i < TILE_SIZE; i++) {
		for(int j = 0; j < TILE_SIZE; j++) {
			printf("%f ", qweight_regs[i][j].to_float());
		}
		printf("\n");
	}
	printf("\n");

	printf("load input: (%d, %d, %d)\n", i, j, k);
	for(int i = 0; i < TILE_SIZE; i++) {
		for(int j = 0; j < TILE_SIZE; j++) {
			printf("%f ", qinput_regs[i][j].to_float());
		}
		printf("\n");
	}
	printf("\n");

}

void compute(
	ap_fixed<8, 4> qinput_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<8, 4> kinput_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<8, 4> vinput_regs[TILE_SIZE][TILE_SIZE],

	ap_fixed<8, 1> qweight_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<8, 1> kweight_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<8, 1> vweight_regs[TILE_SIZE][TILE_SIZE],

	ap_fixed<16, 5> qoutput_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<16, 5> koutput_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<16, 5> voutput_regs[TILE_SIZE][TILE_SIZE],
	int set_not_increment
) {
	for(int tk = 0; tk < TILE_SIZE; tk++) {
#pragma HLS pipeline II=1
		for(int ti = 0; ti < TILE_SIZE; ti++) {
			for(int tj = 0; tj < TILE_SIZE; tj++) {
				ap_fixed<16, 5, AP_RND, AP_SAT> qmul = (ap_fixed<16, 5, AP_RND, AP_SAT>) (qweight_regs[ti][tk] * qinput_regs[tk][tj]);
				ap_fixed<16, 5, AP_RND, AP_SAT> kmul = (ap_fixed<16, 5, AP_RND, AP_SAT>) (kweight_regs[ti][tk] * kinput_regs[tk][tj]);
				ap_fixed<16, 5, AP_RND, AP_SAT> vmul = (ap_fixed<16, 5, AP_RND, AP_SAT>) (vweight_regs[ti][tk] * vinput_regs[tk][tj]);
				if(set_not_increment && tk==0) {
					qoutput_regs[ti][tj] = qmul;
					koutput_regs[ti][tj] = kmul;
					voutput_regs[ti][tj] = vmul;
				}
				else {
					qoutput_regs[ti][tj] += qmul;
					koutput_regs[ti][tj] += kmul;
					voutput_regs[ti][tj] += vmul;
				}
			}
		}
	}
	printf("compute\n");
	for(int i = 0; i < TILE_SIZE; i++) {
		for(int j = 0; j < TILE_SIZE; j++) {
			printf("%f ", qoutput_regs[i][j].to_float());
		}
		printf("\n");
	}
	printf("\n");
}

void regs_to_bram(
	ap_fixed<16, 5> qoutput_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<16, 5> koutput_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<16, 5> voutput_regs[TILE_SIZE][TILE_SIZE],

	ap_fixed<8, 5> q_proj_bram[12][198][64],
	ap_fixed<8, 5> k_proj_bram[12][198][64],
	ap_fixed<8, 5> v_proj_bram[12][198][64],

	int i, int j
) {
	for(int ti = 0; ti < TILE_SIZE; ti++) {
		for(int tj = 0; tj < TILE_SIZE; tj++) {
#pragma HLS pipeline II=1
			int hidx = ti + i * TILE_SIZE, widx = tj + j * TILE_SIZE;
			if(widx < 198 && hidx < 768) {
				int head = hidx / 64;
				int didx = hidx % 64;

				q_proj_bram[head][widx][didx] = (ap_fixed<8, 5, AP_RND, AP_SAT>) (qoutput_regs[ti][tj] + q_linear_bias[hidx]);
				k_proj_bram[head][widx][didx] = (ap_fixed<8, 5, AP_RND, AP_SAT>) (koutput_regs[ti][tj] + k_linear_bias[hidx]);
				v_proj_bram[head][widx][didx] = (ap_fixed<8, 5, AP_RND, AP_SAT>) (voutput_regs[ti][tj] + v_linear_bias[hidx]);

				if(i == 0 && j == 0) {
					printf("sending %f at (%d, %d) to (%d %d %d)\n", q_proj_bram[head][widx][didx].to_float(), hidx, widx, head, widx, didx);
				}
			}
		}
	}
}

void qkv_linear(
	ap_fixed<8, 4> input_bram[198][768],
	ap_fixed<8, 5> q_proj_bram[12][198][64],
	ap_fixed<8, 5> k_proj_bram[12][198][64],
	ap_fixed<8, 5> v_proj_bram[12][198][64]
) {
	ap_fixed<8, 4> qinput_regs[TILE_SIZE][TILE_SIZE];
	ap_fixed<8, 4> kinput_regs[TILE_SIZE][TILE_SIZE];
	ap_fixed<8, 4> vinput_regs[TILE_SIZE][TILE_SIZE];

	ap_fixed<8, 1> qweight_regs[TILE_SIZE][TILE_SIZE];
	ap_fixed<8, 1> kweight_regs[TILE_SIZE][TILE_SIZE];
	ap_fixed<8, 1> vweight_regs[TILE_SIZE][TILE_SIZE];

	ap_fixed<16, 5> qoutput_regs[TILE_SIZE][TILE_SIZE];
	ap_fixed<16, 5> koutput_regs[TILE_SIZE][TILE_SIZE];
	ap_fixed<16, 5> voutput_regs[TILE_SIZE][TILE_SIZE];

#pragma HLS array_partition variable=qinput_regs complete dim=0
#pragma HLS array_partition variable=kinput_regs complete dim=0
#pragma HLS array_partition variable=vinput_regs complete dim=0
#pragma HLS array_partition variable=qweight_regs complete dim=0
#pragma HLS array_partition variable=kweight_regs complete dim=0
#pragma HLS array_partition variable=vweight_regs complete dim=0
#pragma HLS array_partition variable=qoutput_regs complete dim=0
#pragma HLS array_partition variable=koutput_regs complete dim=0
#pragma HLS array_partition variable=voutput_regs complete dim=0

	for(int i = 0; i < 16 / TILE_SIZE; i++) {
		for(int j = 0; j < 16 / TILE_SIZE; j++) {
			for(int k = 0; k < num_nonzero / TILE_SIZE; k++) {
#pragma HLS dataflow
				bram_to_regs(
					input_bram,
					qinput_regs,
					kinput_regs,
					vinput_regs,
					qweight_regs,
					kweight_regs,
					vweight_regs,

					i, j, k
				);

				compute(
					qinput_regs,
					kinput_regs,
					vinput_regs,

					qweight_regs,
					kweight_regs,
					vweight_regs,

					qoutput_regs,
					koutput_regs,
					voutput_regs,
					k==0
				);

				regs_to_bram(
					qoutput_regs,
					koutput_regs,
					voutput_regs,

					q_proj_bram,
					k_proj_bram,
					v_proj_bram,

					i, j
				);

			}
		}
	}
}
