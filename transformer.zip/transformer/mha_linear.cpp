#include "mha0.h"

const int TILE_SIZE = 16;

void bram_to_regs(
	ap_fixed<8, 4> input_bram[198][768],
	ap_fixed<8, 4> input_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<8, 1> weight_regs[TILE_SIZE][TILE_SIZE],

	int i, int j, int k
) {
	ap_uint<12> col_idx = 0;
	for(int outer = 0; outer < TILE_SIZE; outer++) {
		for(int inner = 0; inner < TILE_SIZE; inner++) {
#pragma HLS pipeline II=1
			int weight_hidx = i*TILE_SIZE+outer, weight_widx = k*TILE_SIZE+inner;
			int input_widx = j*TILE_SIZE + outer;

			if(weight_hidx < 768 && weight_widx < num_nonzero) {
				weight_regs[outer][inner] = out_linear_weight[weight_hidx][weight_widx];
				col_idx = out_linear_idx[weight_hidx][weight_widx];
			}

			if(input_widx < 198) {
				input_regs[inner][outer] = input_bram[input_widx][col_idx];
			}
		}
	}
}

void compute(
	ap_fixed<8, 4> input_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<8, 1> weight_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<12, 5> output_regs[TILE_SIZE][TILE_SIZE],
	int set_not_increment
) {
	for(int tk = 0; tk < TILE_SIZE; tk++) {
#pragma HLS pipeline II=1
		for(int ti = 0; ti < TILE_SIZE; ti++) {
			for(int tj = 0; tj < TILE_SIZE; tj++) {
				ap_fixed<12, 5, AP_RND, AP_SAT> mul = (ap_fixed<12, 5, AP_RND, AP_SAT>) (weight_regs[ti][tk] * input_regs[tk][tj]);
				if(set_not_increment && tk==0) {
					output_regs[ti][tj] = mul;
				}
				else {
					output_regs[ti][tj] += mul;
				}
			}
		}
	}
}

void regs_to_bram(
	ap_fixed<12, 5> output_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<8, 3> output_bram[198][768],

	int i, int j
) {
	for(int ti = 0; ti < TILE_SIZE; ti++) {
		for(int tj = 0; tj < TILE_SIZE; tj++) {
#pragma HLS pipeline II=1
			int hidx = ti + i * TILE_SIZE, widx = tj + j * TILE_SIZE;
			if(widx < 198 && hidx < 768)
				output_bram[widx][hidx] = (ap_fixed<8, 3, AP_RND, AP_SAT>) (output_regs[ti][tj] + out_linear_bias[hidx]);
		}
	}
}

void mha_out_linear(
	ap_fixed<8, 4> input_bram[198][768],
	ap_fixed<8, 3> output_bram[198][768]
) {
	ap_fixed<8, 4> input_regs[TILE_SIZE][TILE_SIZE];
	ap_fixed<8, 1> weight_regs[TILE_SIZE][TILE_SIZE];
	ap_fixed<12, 5> output_regs[TILE_SIZE][TILE_SIZE];

#pragma HLS array_partition variable=input_regs complete dim=0
#pragma HLS array_partition variable=weight_regs complete dim=0
#pragma HLS array_partition variable=output_regs complete dim=0

	for(int i = 0; i < 768/TILE_SIZE; i++) {
		for(int j = 0; j < 198/TILE_SIZE; j++) {
			for(int k = 0; k < num_nonzero/TILE_SIZE; k++) {
#pragma dataflow
				bram_to_regs(
					input_bram,
					input_regs,
					weight_regs,
					i, j, k
				);
				compute(
					input_regs,
					weight_regs,
					output_regs,
					k==0
				);
				regs_to_bram(
					output_regs,
					output_bram,
					i, j
				);
			}
		}
	}
}
