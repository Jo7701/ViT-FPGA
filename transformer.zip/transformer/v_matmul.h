#ifndef __V_MATMUL_H__
#define __V_MATMUL_H__

#include <ap_fixed.h>

void v_matmul(
		ap_fixed<8,1> input_bram[12][198][198],
		ap_fixed<8, 5> v_proj_bram[12][198][64],
		ap_fixed<8, 4> output_bram[198][768]
);

#endif
