#include "deit.h"
#include <stdio.h>

void embedder(
		ap_fixed<8,1>* weight_ddr, ap_fixed<8, 4>* bias_ddr, ap_fixed<8, 1>* input_ddr,
		ap_fixed<8,1> input_bram[198][768], ap_fixed<8, 4> output_bram[198][768]
) {
#pragma HLS interface m_axi depth=1024 port=weight_ddr bundle=gmem0
#pragma HLS interface m_axi depth=1024 port=bias_ddr bundle=gmem1
#pragma HLS interface m_axi depth=1024 port=input_ddr bundle=gmem2

	for(int patch_hidx = 0, dim1_iter=0; patch_hidx < img_size / patch_size; patch_hidx++) {
		for(int patch_widx = 0; patch_widx < img_size / patch_size; patch_widx++, dim1_iter++) {
			for(int i = 0, dim2_iter = 0; i < patch_size; i++) {
				for(int j = 0; j < patch_size * num_channels; j++, dim2_iter++) {
#pragma HLS pipeline II=1
					int hidx = patch_hidx*patch_size + i;
					int widx = patch_widx*patch_size*num_channels+j;
					int addr = hidx*img_size*num_channels + widx;
					input_bram[dim1_iter][dim2_iter] = input_ddr[addr];
				}
			}
		}
	}

	emb_matmul(weight_ddr, bias_ddr, input_bram, output_bram);
}

void mha (
		ap_fixed<8, 4> input_bram[198][768],
		ap_fixed<8, 5> q_proj_bram[12][198][64],
		ap_fixed<8, 5> k_proj_bram[12][198][64],
		ap_fixed<8, 5> v_proj_bram[12][198][64],
		ap_fixed<8, 6> scores_bram[12][198][198],
		ap_fixed<8, 1> softmax_bram[12][198][198],
		ap_fixed<8, 3> output_bram[198][768]
) {
	qkv_linear(
		input_bram,
		q_proj_bram,
		k_proj_bram,
		v_proj_bram
	);

	qk_matmul(
		q_proj_bram,
		k_proj_bram,
		scores_bram
	);

	softmax(
		scores_bram,
		softmax_bram
	);

	v_matmul(
		softmax_bram,
		v_proj_bram,
		input_bram
	);

	mha_out_linear(
		input_bram,
		output_bram
	);
}
