#include "deit.h"
#include <iostream>
#include <fstream>
#include <stdio.h>
using namespace std;

int encode_sparse
(
	ap_fixed<8, 8>* dense, ap_fixed<20, 20>* sparse,
	int height, int width
) {
	int num_nonzero = 0;
	for(int i = 0, iter=0; i < height; i++) {
		for(int j = 0; j < width; j++) {
			if(dense[i*width+j] != 0.0) {
				sparse[iter] = (ap_fixed<20, 20>) (((ap_fixed<8, 8>) dense[i*width+j]) << 12 | (ap_fixed<12, 12>) j);
				if(i == 0)
					num_nonzero++;
			}
		}
	}
	return num_nonzero;
}

int verify_rearranged(
	ap_fixed<8, 1> input_bram[198][768], ap_fixed<8, 1>* rearranged
) {
	for(int i = 0; i < 196; i++) {
		for(int j = 0; j < 768; j++) {
			if(input_bram[i][j] != rearranged[i*768+j]) {
				printf("Rearranged mismatch at (%d, %d). Expected: %f, Got: %f\n", i, j, rearranged[i*768+j].to_float(), input_bram[i][j].to_float());
//				return -1;
			}
		}
	}
	return 0;
}

int verify_embeddings(
	ap_fixed<8, 4> output_bram[198][768], ap_fixed<8, 4>* golden
) {
	for(int i = 0; i < 32; i++) {
		for(int j = 0; j < 32; j++) {
			if(abs(output_bram[i][j].to_float() - golden[i*768+j].to_float()) > 0.1) {
				printf("Mismatch at (%d, %d). Expected %f. Got %f.\n", i, j, golden[i*768+j].to_float(), output_bram[i][j].to_float());
			}
		}
	}
}


int maain() {
	int height = 768;
	int width = 768;
	int seq_len = 198;

	string line;
	ifstream weights_file("embedder.txt");

	if(weights_file.fail())
		printf("lol weights\n");

	ap_fixed<8,1>* weights = new ap_fixed<8,1>[height*width+1000];
	ap_fixed<8, 4>* bias = new ap_fixed<8, 4>[seq_len*height+4096];

	int weight_idx = 0, bias_idx = 0;
	while(getline(weights_file, line)) {
		if(weight_idx < height*width) {
			weights[weight_idx] = (ap_fixed<8,1>) stof(line);
			weight_idx++;
		}
		else {
			bias[bias_idx] = (ap_fixed<8, 4>) stof(line);
			bias_idx++;
		}
	}

	int batch_size = 1;

	ap_fixed<8, 1>* input = new ap_fixed<8, 1>[batch_size * 224 * 224 * 3];
	ifstream image_file("images.txt");

	if(image_file.fail())
		printf("lol img\n");

	int inp_idx = 0;
	while(getline(image_file, line)) {
		if(inp_idx >= batch_size*224*224*3)
			break;
		else {
			input[inp_idx] = (ap_fixed<8, 1>) stof(line);
			inp_idx++;
		}
	}

	ap_fixed<8, 1> input_bram[198][768];
	ap_fixed<8, 4> output_bram[198][768];

//	printf("Printing Weights\n");
//	for(int i = 0; i < 768; i++) {
//		for(int j = 0; j < 768; j++) {
//			printf("%f ", weights[i*768+j].to_float());
//		}
//		printf("\n");
//	}
//	printf("\nPrinting Input\n");

	embedder(
			weights, bias, input,
			input_bram, output_bram
	);

	ifstream golden_rearrange_file("embedder_rearranged.txt");
	if(golden_rearrange_file.fail())
		printf("fuck\n");
	ap_fixed<8, 1>* golden_rearranged = new ap_fixed<8, 1>[224*224*3];

	int golden_idx = 0;
	while(getline(golden_rearrange_file, line)) {
		golden_rearranged[golden_idx] = (ap_fixed<8, 1>) stof(line);
		golden_idx++;
	}

	verify_rearranged(input_bram, golden_rearranged);

	delete[] golden_rearranged;
	delete[] weights;
	delete[] bias;
	delete[] input;

	ap_fixed<8, 4>* golden_embeddings = new ap_fixed<8, 4>[198*768];
	ifstream golden_embedding_file("embedder_embeddings.txt");
	if(golden_embedding_file.fail())
		printf("Didn't open golden embedding file\n");

	golden_idx = 0;
	while(getline(golden_embedding_file, line)) {
		golden_embeddings[golden_idx] = (ap_fixed<8, 4>) stof(line);
		golden_idx++;
	}

	verify_embeddings(output_bram, golden_embeddings);

	delete[] golden_embeddings;
	return 0;
}
