#include "fused_mlp.h"

void bram_to_regs1(
	ap_fixed<8, 6> input_bram[198][768],
	ap_fixed<8, 6> input1_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<8, 1> weight1_regs[TILE_SIZE][TILE_SIZE],
	int i, int j, int k
) {
	ap_uint<12> col_idx;
	for(int outer = 0; outer < TILE_SIZE; outer++) {
		for(int inner = 0; inner < TILE_SIZE; inner++) {
#pragma HLS pipeline II=1
			int weight_hidx = outer + i*TILE_SIZE, weight_widx = inner + k*TILE_SIZE;
			int input_widx = outer + j*TILE_SIZE;

			if(weight_hidx < 3072 && weight_widx < 198) {
				weight1_regs[outer][inner] = linear1_weight[weight_hidx][weight_widx];
				col_idx = linear1_idx[weight_hidx][weight_widx];
			}
			else
				weight1_regs[outer][inner] = 0.0;

			if(input_widx < 198)
				input1_regs[inner][outer] = input_bram[col_idx][input_widx];
		}
	}
}

void bram_to_regs2(
	ap_fixed<8, 3> intermediate[3072][TILE_SIZE],
	ap_fixed<8, 3> input2_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<8, 1> weight2_regs[TILE_SIZE][TILE_SIZE],
	int i, int k
) {
	ap_uint<12> col_idx;
	for(int outer = 0; outer < TILE_SIZE; outer++) {
		for(int inner = 0; inner < TILE_SIZE; inner++) {
#pragma HLS pipeline II=1
			int weight_hidx = outer + i*TILE_SIZE, weight_widx = inner + k*TILE_SIZE;
			int input_widx = outer;

			if(weight_hidx < 768 && weight_widx < 198) {
				weight2_regs[outer][inner] = linear2_weight[weight_hidx][weight_widx];
				col_idx = linear2_idx[weight_hidx][weight_widx];
			}
			else
				weight2_regs[outer][inner] = 0.0;

			input2_regs[inner][outer] = intermediate[col_idx][input_widx];
		}
	}
}

void compute1(
	ap_fixed<8, 6> input_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<8, 1> weight_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<12, 5> output_regs[TILE_SIZE][TILE_SIZE],
	int set_not_increment
) {
	for(int tk = 0; tk < TILE_SIZE; tk++) {
#pragma HLS pipeline II=1
		for(int ti = 0; ti < TILE_SIZE; ti++) {
			for(int tj = 0; tj < TILE_SIZE; tj++) {
				ap_fixed<12, 5, AP_RND, AP_SAT> mul = (ap_fixed<12, 5, AP_RND, AP_SAT>) (weight_regs[ti][tk] * input_regs[tk][tj]);
				if(set_not_increment && tk==0) {
					output_regs[ti][tj] = mul;
				}
				else {
					output_regs[ti][tj] += mul;
				}
			}
		}
	}
}

void compute2(
	ap_fixed<8, 3> input_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<8, 1> weight_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<12, 5> output_regs[TILE_SIZE][TILE_SIZE],
	int set_not_increment
) {
	for(int tk = 0; tk < TILE_SIZE; tk++) {
#pragma HLS pipeline II=1
		for(int ti = 0; ti < TILE_SIZE; ti++) {
			for(int tj = 0; tj < TILE_SIZE; tj++) {
				ap_fixed<12, 5, AP_RND, AP_SAT> mul = (ap_fixed<12, 5, AP_RND, AP_SAT>) (weight_regs[ti][tk] * input_regs[tk][tj]);
				if(set_not_increment && tk==0) {
					output_regs[ti][tj] = mul;
				}
				else {
					output_regs[ti][tj] += mul;
				}
			}
		}
	}
}

void regs_to_bram1(
	ap_fixed<12, 5> intermediate_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<8, 3> intermediate[3072][TILE_SIZE],

	int i
) {
	for(int ti = 0; ti < TILE_SIZE; ti++) {
		for(int tj = 0; tj < TILE_SIZE; tj++) {
#pragma HLS pipeline II=1
			int hidx = ti + i * TILE_SIZE, widx = tj;
			ap_fixed<8, 3, AP_RND, AP_SAT> result = (ap_fixed<8, 3, AP_RND, AP_SAT>) (intermediate_regs[ti][tj] + linear1_bias[hidx]);
			if(hidx < 3072)
				intermediate[widx][hidx] = (ap_fixed<8, 3, AP_RND, AP_SAT>) result;//result < 0 ? result / 64 : result; //apply LeakyRelu
			else
				intermediate[widx][hidx] = 0.0;
		}
	}
}

void regs_to_bram2(
	ap_fixed<12, 5> output_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<8, 3> output_bram[198][768],

	int i, int j
) {
	for(int ti = 0; ti < TILE_SIZE; ti++) {
		for(int tj = 0; tj < TILE_SIZE; tj++) {
#pragma HLS pipeline II=1
			int hidx = ti + i * TILE_SIZE, widx = tj + j * TILE_SIZE;
			if(hidx < 768 && widx < 198)
				output_bram[widx][hidx] = (ap_fixed<8, 3, AP_RND, AP_SAT>) (output_regs[ti][tj] + linear2_bias[hidx]);
			else
				output_bram[widx][hidx] = 0.0;
		}
	}
}

void fused_mlp(
	ap_fixed<8, 6> input_bram[198][768],
	ap_fixed<8, 3> intermediate[3072][TILE_SIZE],
	ap_fixed<8, 3> output_bram[198][768]
) {
	ap_fixed<8, 6> input1_regs[TILE_SIZE][TILE_SIZE];
	ap_fixed<8, 1> weight1_regs[TILE_SIZE][TILE_SIZE];
	ap_fixed<12, 5> intermediate_regs[TILE_SIZE][TILE_SIZE];
	ap_fixed<8, 3> input2_regs[TILE_SIZE][TILE_SIZE];
	ap_fixed<8, 1> weight2_regs[TILE_SIZE][TILE_SIZE];
	ap_fixed<12, 5> output_regs[TILE_SIZE][TILE_SIZE];

#pragma HLS array_partition variable=input1_regs complete dim=0
#pragma HLS array_partition variable=weight1_regs complete dim=0
#pragma HLS array_partition variable=intermediate_regs complete dim=0
#pragma HLS array_partition variable=input2_regs complete dim=0
#pragma HLS array_partition variable=weight2_regs complete dim=0
#pragma HLS array_partition variable=output_regs complete dim=0

	for(int i = 0; i < 3072/TILE_SIZE; i++) {
		for(int j = 0; j < 198/TILE_SIZE; j++) {
			for(int k = 0; k < num_nonzero1/TILE_SIZE; k++) {
#pragma HLS dataflow

			}
		}

		for(int l = 0; l < 768/TILE_SIZE; l++) {
			for(int m = 0; m < num_nonzero2/TILE_SIZE; m++) {
#pragma HLS dataflow

			}
		}
	}
}
