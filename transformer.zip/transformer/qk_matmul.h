#ifndef __QK_MATMUL_H__
#define __QK_MATMUL_H__

#include <ap_fixed.h>

void qk_matmul(
	ap_fixed<8, 5> q_proj_bram[12][198][64],
	ap_fixed<8, 5> k_proj_bram[12][198][64],
	ap_fixed<8, 6> qk_bram[12][198][198]
);

#endif
