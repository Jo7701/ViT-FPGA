#include "embedder_matmul.h"
#include <stdio.h>

const int TILE_SIZE=16;

void load_regs
(
	ap_fixed<8,1>* weight_ddr, ap_fixed<8, 4>* bias_ddr,
	ap_fixed<8,1> input_bram[198][768],
	ap_fixed<8, 1> weight_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<8, 4> bias_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<8, 1> input_regs[TILE_SIZE][TILE_SIZE],
	int i, int j, int k
) {
	ap_fixed<8, 1> weight_val;
	ap_fixed<8, 1> input_val;

	for(int outer = 0; outer < TILE_SIZE; outer++) {
		for(int inner = 0; inner < TILE_SIZE; inner++) {
#pragma HLS pipeline

			int weight_hidx = i*TILE_SIZE+outer, weight_widx = k*TILE_SIZE+inner;
			int input_hidx = k*TILE_SIZE+inner, input_widx = j*TILE_SIZE + outer;

			//assumes ddr ptrs are padded so no invalid indeces are accessed
			ap_fixed<8,1> weight = weight_ddr[weight_hidx*768+weight_widx];
			ap_fixed<12, 6> bias_val = bias_ddr[(2+j*TILE_SIZE+inner)*198 + i*TILE_SIZE+outer]; //transpose bias

			if(weight_hidx < emb_size && weight_widx < emb_size)
				weight_val = (ap_fixed<8, 1>)  weight;
			else
				weight_val = (ap_fixed<8, 1>) 0.0;

			if(input_widx < 196 && input_hidx < 768)
				input_val = (ap_fixed<8, 1>) input_bram[input_widx][input_hidx]; //transpose input
			else
				input_val = (ap_fixed<8, 1>) 0.0;

			weight_regs[outer][inner] = weight_val;
			bias_regs[outer][inner] = bias_val;
			input_regs[inner][outer] = input_val;
		}
	}
//	printf("Input tile at (i,j,k)=(%d, %d, %d)\n", i, j, k);
//	for(int i = 0; i < TILE_SIZE; i++) {
//		for(int j = 0; j < TILE_SIZE; j++) {
//			printf("%f ", input_regs[i][j].to_float());
//		}
//		printf("\n");
//	}
//	printf("\nWeight tile at (i,j,k)=(%d, %d, %d)\n", i, j, k);
//	for(int i = 0; i < TILE_SIZE; i++) {
//		for(int j = 0; j < TILE_SIZE; j++) {
//			printf("%f ", weight_regs[i][j].to_float());
//		}
//		printf("\n");
//	}
//	printf("\nBias Tile at (i,j,k)=(%d, %d, %d)\n", i, j, k);
//	for(int i = 0; i < TILE_SIZE; i++) {
//		for(int j = 0; j < TILE_SIZE; j++) {
//			printf("%f ", bias_regs[i][j].to_float());
//		}
//		printf("\n");
//	}
//	printf("\n");
}

void compute
(
		ap_fixed<8, 1> weight_regs[TILE_SIZE][TILE_SIZE],
		ap_fixed<8, 1> input_regs[TILE_SIZE][TILE_SIZE],
		ap_fixed<12, 6, AP_RND, AP_SAT> output_regs[TILE_SIZE][TILE_SIZE],
		ap_fixed<8, 4> bias_regs0[TILE_SIZE][TILE_SIZE],
		ap_fixed<8, 4> bias_regs1[TILE_SIZE][TILE_SIZE],
		int set_not_increment
) {
	for(int tk = 0; tk < TILE_SIZE; tk++) {
#pragma HLS PIPELINE II=1
		for(int ti = 0; ti < TILE_SIZE; ti++) {
			for(int tj = 0; tj < TILE_SIZE; tj++) {
				if(set_not_increment && tk==0) {
					output_regs[ti][tj] = (ap_fixed<12, 6, AP_RND, AP_SAT>) (weight_regs[ti][tk] * input_regs[tk][tj]);
				}
				else {
					output_regs[ti][tj] += (ap_fixed<12, 6, AP_RND, AP_SAT>) (weight_regs[ti][tk] * input_regs[tk][tj]);
				}
				bias_regs1[ti][tj] = bias_regs0[ti][tj];
			}
		}
	}
//	printf("Compute Tile\n");
//	for(int i = 0; i < TILE_SIZE; i++) {
//		for(int j = 0; j < TILE_SIZE; j++) {
//			printf("%f ", output_regs[i][j].to_float());
//		}
//		printf("\n");
//	}
//	printf("\n");
}

void regs_to_bram
(
	ap_fixed<8, 4> output_bram[198][768],
	ap_fixed<12, 6, AP_RND, AP_SAT> output_regs[TILE_SIZE][TILE_SIZE],
	ap_fixed<8, 4> bias_regs[TILE_SIZE][TILE_SIZE],
	int i, int j
) {
	for(int ti = 0; ti < TILE_SIZE; ti++) {
		for(int tj = 0; tj < TILE_SIZE; tj++) {
#pragma HLS PIPELINE II=1
			if(ti+i*TILE_SIZE < 768 && tj+j*TILE_SIZE < 196) {
				output_bram[2+tj+j*TILE_SIZE][ti+i*TILE_SIZE] = (ap_fixed<8,4, AP_RND, AP_SAT>) (output_regs[ti][tj] + bias_regs[ti][tj]);
			}
		}
	}
}
/*
 *
 */
void emb_matmul(
		ap_fixed<8,1>* weight_ddr,
		ap_fixed<8, 4>* bias_ddr,
		ap_fixed<8,1> input_bram[198][768],
		ap_fixed<8, 4> output_bram[198][768]
) {
	ap_fixed<8, 1> weight_regs[TILE_SIZE][TILE_SIZE];
	ap_fixed<8, 4> bias_regs0[TILE_SIZE][TILE_SIZE];
	ap_fixed<8, 4> bias_regs1[TILE_SIZE][TILE_SIZE]; //copy node for dataflow efficiency
	ap_fixed<8, 1> input_regs[TILE_SIZE][TILE_SIZE];
	ap_fixed<12, 6, AP_RND, AP_SAT> output_regs[TILE_SIZE][TILE_SIZE];

#pragma HLS array_partition variable=weight_regs complete dim=0
#pragma HLS array_partition variable=bias_regs0 complete dim=0
#pragma HLS array_partition variable=bias_regs1 complete dim=0
#pragma HLS array_partition variable=input_regs complete dim=0
#pragma HLS array_partition variable=output_regs complete dim=0

	//iterate over rows
	for(int i = 0; i < 768/TILE_SIZE; i++) {
		//iterate over columns
		for(int j = 0; j < 196/TILE_SIZE; j++) {
			for(int k = 0; k < 768/TILE_SIZE; k++) {
#pragma HLS dataflow
				load_regs
				(
					weight_ddr, bias_ddr, input_bram,
					weight_regs, bias_regs0, input_regs,
					i, j, k
				);
				compute
				(
					weight_regs,
					input_regs,
					output_regs,
					bias_regs0, bias_regs1,
					k==0
				);
				regs_to_bram
				(
					output_bram,
					output_regs,
					bias_regs1,
					i, j
				);
			}
		}
	}

	for(int i = 0; i < 768; i++) {
#pragma HLS pipeline II=1
		output_bram[0][i] = (ap_fixed<8, 4, AP_RND, AP_SAT>) (cls_token[i] + bias_ddr[i]);
	}

	for(int i = 0; i < 768; i++) {
#pragma HLS pipeline II=1
		output_bram[1][i] = (ap_fixed<8, 4, AP_RND, AP_SAT>) (distillation_token[i] + bias_ddr[768+i]);
	}

}
