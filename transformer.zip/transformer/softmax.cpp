#include "softmax.h"

void softmax(
	ap_fixed<8,6> input_bram[12][198][198],
	ap_fixed<8,1> output_bram[12][198][198]
) {
	ap_fixed<8,6> max_regs[12][198];
	ap_fixed<16,8> sum_regs[12][198];

#pragma HLS array_partition variable=max_regs complete dim=1
#pragma HLS array_partition variable=sum_regs complete dim=1
#pragma HLS array_partition variable=input_bram complete dim=1

	for(int i = 0; i < 198; i++) {
		for(int j = 0; j < 198; j++) {
#pragma HLS pipeline II=1
			for(int head = 0; head < 12; head++) {
#pragma HLS unroll
				if(j == 0 || input_bram[head][i][j] > max_regs[head][i])
					max_regs[head][i] = input_bram[head][i][j];
			}
		}
	}

	//perform lookup[val-max] in one step and store to running accumulator
	for(int i = 0; i < 198; i++) {
		for(int j = 0; j < 198; j++) {
#pragma HLS pipeline II=1
			for(int head = 0; head < 12; head++) {
#pragma HLS unroll
				ap_fixed<8, 6, AP_RND, AP_SAT> translated = input_bram[head][i][j] - max_regs[head][i];
				ap_fixed<8, 6, AP_RND, AP_SAT> e_pow_val = softmax_lookup[translated];
				input_bram[head][i][j] = e_pow_val;
				if(j == 0)
					sum_regs[head][i] = e_pow_val;
				else
					sum_regs[head][i] += e_pow_val;
			}
		}
	}

	//perform val / sum
	for(int i = 0; i < 198; i++) {
		for(int j = 0; j < 198; j++) {
#pragma HLS pipeline II=1
			for(int head = 0; head < 12; head++) {
#pragma HLS unroll
				output_bram[head][i][j] = (ap_fixed<8, 1, AP_RND, AP_SAT>) (input_bram[head][i][j] / sum_regs[head][i]);
			}
		}
	}

}
