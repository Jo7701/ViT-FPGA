#include "mha0.h"
#include <ap_fixed.h>
#include <iostream>
#include <fstream>
#include <stdio.h>

using namespace std;

int verify_qkv_proj(ap_fixed<8, 5> proj_bram[12][198][64], ap_fixed<8, 5>* golden) {
	for(int i = 0, idx = 0; i < 12; i++) {
		for(int j = 0; j < 198; j++) {
			for(int k = 0; k < 64; k++, idx++) {
				if(golden[idx].to_float() != proj_bram[i][j][k].to_float() && idx < 64) {
					printf("Mismatch at (%d, %d, %d). Expected %f, got %f\n", i, j, k, golden[idx].to_float(), proj_bram[i][j][k].to_float());
				}
			}
		}
	}
	return 0;
}

int maaain() {
	string line;

	ap_fixed<8, 4> input_bram[198][768];
	ap_fixed<8, 5> q_proj_bram[12][198][64];
	ap_fixed<8, 5> k_proj_bram[12][198][64];
	ap_fixed<8, 5> v_proj_bram[12][198][64];

	ap_fixed<8, 4>* q_linear_bias = new ap_fixed<8, 4>[768];
	ap_fixed<8, 4>* k_linear_bias = new ap_fixed<8, 4>[768];
	ap_fixed<8, 4>* v_linear_bias = new ap_fixed<8, 4>[768];

	ap_fixed<8, 1>** q_linear_weight = new ap_fixed<8, 1>*[768];
	ap_fixed<8, 1>** k_linear_weight = new ap_fixed<8, 1>*[768];
	ap_fixed<8, 1>** v_linear_weight = new ap_fixed<8, 1>*[768];

	ap_uint<12>** q_linear_idx = new ap_uint<12>*[768];
	ap_uint<12>** k_linear_idx = new ap_uint<12>*[768];
	ap_uint<12>** v_linear_idx = new ap_uint<12>*[768];

	for(int i = 0; i < 768; i++) {
		q_linear_weight[i] = new ap_fixed<8,1>[num_nonzero];
		k_linear_weight[i] = new ap_fixed<8,1>[num_nonzero];
		v_linear_weight[i] = new ap_fixed<8,1>[num_nonzero];
		q_linear_idx[i] = new ap_uint<12>[num_nonzero];
		k_linear_idx[i] = new ap_uint<12>[num_nonzero];
		v_linear_idx[i] = new ap_uint<12>[num_nonzero];
	}

	ifstream qlinear("q_linear.txt");
	int widx = 0, cidx = 0, bidx = 0;
	while(getline(qlinear, line)) {
		if(widx < 768*num_nonzero) {
			q_linear_weight[widx/num_nonzero][widx%num_nonzero] = (ap_fixed<8,1>) stof(line);
			widx++;
		}
		else if(cidx < 768*num_nonzero) {
			q_linear_idx[cidx/num_nonzero][cidx%num_nonzero] = (ap_uint<12>) stof(line);
			cidx++;
		}
		else {
			q_linear_bias[bidx] = (ap_fixed<8, 4>) stof(line);
			bidx++;
		}
	}

	ifstream vlinear("v_linear.txt");
	widx = 0, cidx = 0, bidx = 0;
	while(getline(vlinear, line)) {
		if(widx < 768*num_nonzero) {
			v_linear_weight[widx/num_nonzero][widx%num_nonzero] = (ap_fixed<8,1>) stof(line);
			widx++;
		}
		else if(cidx < 768*num_nonzero) {
			v_linear_idx[cidx/num_nonzero][cidx%num_nonzero] = (ap_uint<12>) stof(line);
			cidx++;
		}
		else {
			v_linear_bias[bidx] = (ap_fixed<8, 4>) stof(line);
			bidx++;
		}
	}


	ifstream klinear("k_linear.txt");
	if(klinear.fail())
		printf("Cant open k_linear.txt\n");

	widx = 0, cidx = 0, bidx = 0;
	while(getline(klinear, line)) {
		if(widx < 768*num_nonzero) {
			k_linear_weight[widx/num_nonzero][widx%num_nonzero] = (ap_fixed<8, 1>) stof(line);
			widx++;
		}
		else if (cidx < 768*num_nonzero) {
			k_linear_idx[cidx/num_nonzero][cidx%num_nonzero] = (ap_uint<12>) stof(line);
			cidx++;
		}
		else{
			k_linear_bias[bidx] = (ap_fixed<8, 4>) stof(line);
			bidx++;
		}
	}

	ifstream emb("mha_embeddings_inp.txt");
	int idx = 0;
	while(getline(emb, line)) {
		input_bram[idx/768][idx%768] = (ap_fixed<8, 4>) stof(line);
		idx++;
	}

	for(int i = 0; i < 768; i++) {
		for(int j = 0; j < num_nonzero; j++) {
			printf("%d ", q_linear_idx[i][j].to_int());
		}
		printf("\n");
	}
	printf("\n");

	qkv_linear(input_bram, q_proj_bram, k_proj_bram, v_proj_bram,

			q_linear_bias,
			k_linear_bias,
			v_linear_bias,

			q_linear_weight,
			k_linear_weight,
			v_linear_weight,

			q_linear_idx,
			k_linear_idx,
			v_linear_idx);

	ap_fixed<8, 5>* golden = new ap_fixed<8, 5>[198*768];

	ifstream qproj("q_proj.txt");
	idx = 0;
	while(getline(qproj, line)) {
		golden[idx] = (ap_fixed<8, 5>) stof(line);
		idx++;
	}

	verify_qkv_proj(q_proj_bram, golden);

	ifstream kproj("k_proj.txt");
	idx = 0;
	while(getline(kproj, line)) {
		golden[idx] = (ap_fixed<8, 5>) stof(line);
		idx++;
	}

	verify_qkv_proj(k_proj_bram, golden);

	ifstream vproj("v_proj.txt");
	idx = 0;
	while(getline(vproj, line)) {
		golden[idx] = (ap_fixed<8, 5>) stof(line);
		idx++;
	}

	verify_qkv_proj(v_proj_bram, golden);


	delete[] golden;

	for(int i = 0; i < 768; i++) {
		delete[] q_linear_weight[i];
		delete[] k_linear_weight[i];
		delete[] v_linear_weight[i];
		delete[] q_linear_idx[i];
		delete[] k_linear_idx[i];
		delete[] v_linear_idx[i];
	}

	delete[] q_linear_weight;
	delete[] k_linear_weight;
	delete[] v_linear_weight;
	delete[] q_linear_idx;
	delete[] k_linear_idx;
	delete[] v_linear_idx;
	delete[] q_linear_bias;
	delete[] k_linear_bias;
	delete[] v_linear_bias;


	return 0;
}
