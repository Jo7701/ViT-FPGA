#include "softmax.h"

int main() {
	for(float i = -32.0; i <= 32.0; i+=.25) {
		printf("idx: %d; %f -> %f\n", (((ap_uint<10>)(((ap_fixed<8,6>) i) << 2)) >> 2), ((ap_fixed<8,6>) i).to_float(), softmax_lookup[((ap_fixed<10, 8>)(((ap_fixed<8,6>) i) << 2) >> 2).to_int()].to_float());
	}
}
