#include "v_matmul.h"

const int TILE_SIZE = 8;

void bram_to_regs(
	ap_fixed<8, 1> input_bram[12][198][198],
	ap_fixed<8, 5> v_proj_bram[12][198][64],
	ap_fixed<8, 1> input_regs[12][TILE_SIZE][TILE_SIZE],
	ap_fixed<8, 5> v_regs[12][TILE_SIZE][TILE_SIZE],
	int i, int j, int k
) {
	for(int head = 0; head < 12; head++) {
		for(int outer = 0; outer < TILE_SIZE; outer++) {
			for(int inner = 0; inner < TILE_SIZE; inner++) {
#pragma HLS pipeline II=1
				int inp_hidx = i*TILE_SIZE+outer, inp_widx = k*TILE_SIZE+inner;
				int v_hidx = k*TILE_SIZE+inner, v_widx = j*TILE_SIZE + outer;

				if(inp_hidx < 198 && inp_widx < 198) {
					input_regs[head][outer][inner] = input_bram[head][inp_hidx][inp_widx];
				}
				if(v_hidx < 198 && v_widx < 64) {
					v_regs[head][inner][outer] = v_proj_bram[head][v_hidx][v_widx];
				}
			}
		}
	}
}

void compute(
	ap_fixed<8, 1> input_regs[12][TILE_SIZE][TILE_SIZE],
	ap_fixed<8, 5> vregs[12][TILE_SIZE][TILE_SIZE],
	ap_fixed<12, 5> out_regs[12][TILE_SIZE][TILE_SIZE],
	int set_not_increment
) {
	for(int tk = 0; tk < TILE_SIZE; tk++) {
#pragma HLS pipeline II=1
		for(int th = 0; th < 12; th++) {
			for(int ti = 0; ti < TILE_SIZE; ti++) {
				compute_label0:for(int tj = 0; tj < TILE_SIZE; tj++) {
					ap_fixed<12, 5, AP_RND, AP_SAT> mul = (ap_fixed<12, 5, AP_RND, AP_SAT>) (input_regs[th][ti][tk] * vregs[th][tk][tj]);
					if(set_not_increment && tk==0)
						out_regs[th][ti][tj] = mul;
					else
						out_regs[th][ti][tj] += mul;
				}
			}
		}
	}
}

void regs_to_bram(
		ap_fixed<12, 5> out_regs[12][TILE_SIZE][TILE_SIZE],
		ap_fixed<8, 4> output_bram[198][768],
	int i, int j
) {
	for(int head = 0; head < 12; head++) {
		for(int ti = 0; ti < TILE_SIZE; ti++) {
			for(int tj = 0; tj < TILE_SIZE; tj++) {
#pragma HLS pipeline II=1
				int hidx = i*TILE_SIZE+ti, widx = j*TILE_SIZE+tj;
				if(hidx < 198 && widx < 64)
					output_bram[hidx][head*64+widx] = (ap_fixed<8, 4>) out_regs[head][ti][tj];
			}
		}
	}
}

void v_matmul(
		ap_fixed<8, 1> input_bram[12][198][198],
		ap_fixed<8, 5> v_proj_bram[12][198][64],
		ap_fixed<8, 4> output_bram[198][768]
) {
	ap_fixed<8, 1> input_regs[12][TILE_SIZE][TILE_SIZE];
	ap_fixed<8, 5> v_regs[12][TILE_SIZE][TILE_SIZE];
	ap_fixed<12, 5> out_regs[12][TILE_SIZE][TILE_SIZE];

#pragma HLS array_partition variable=input_regs complete dim=0
#pragma HLS array_partition variable=v_regs complete dim=0
#pragma HLS array_partition variable=out_regs complete dim=0

	for(int i = 0; i < 198/TILE_SIZE; i++) {
		for(int j = 0; j < 64/TILE_SIZE; j++) {
			for(int k = 0; k < 198/TILE_SIZE; k++) {
#pragma dataflow
				bram_to_regs(
					input_bram,
					v_proj_bram,
					input_regs,
					v_regs,
					i, j, k
				);
				compute(
					input_regs,
					v_regs,
					out_regs,
					k==0
				);
				regs_to_bram(
					out_regs,
					output_bram,
					i, j
				);
			}
		}
	}
}
