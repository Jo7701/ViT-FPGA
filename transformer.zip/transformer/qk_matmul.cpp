#include "qk_matmul.h"

const int TILE_SIZE = 8;

void bram_to_regs(
	ap_fixed<8, 5> q_proj_bram[12][198][64],
	ap_fixed<8, 5> k_proj_bram[12][198][64],
	ap_fixed<8, 5> qregs[12][TILE_SIZE][TILE_SIZE],
	ap_fixed<8, 5> kregs[12][TILE_SIZE][TILE_SIZE],
	int i, int j, int k
) {
	for(int head = 0; head < 12; head++) {
		for(int outer = 0; outer < TILE_SIZE; outer++) {
			for(int inner = 0; inner < TILE_SIZE; inner++) {
#pragma HLS pipeline II=1
				int q_hidx = i*TILE_SIZE+outer, q_widx = k*TILE_SIZE+inner;
				int k_hidx = k*TILE_SIZE+inner, k_widx = j*TILE_SIZE + outer;

				if(q_hidx < 198 && q_widx < 64) {
					qregs[head][outer][inner] = q_proj_bram[head][q_hidx][q_widx];
				}
				if(k_hidx < 64 && k_widx < 198) {
					kregs[head][inner][outer] = k_proj_bram[head][k_widx][k_hidx];
				}
			}
		}
	}
}

void compute(
	ap_fixed<8, 5> qregs[12][TILE_SIZE][TILE_SIZE],
	ap_fixed<8, 5> kregs[12][TILE_SIZE][TILE_SIZE],
	ap_fixed<16, 10> out_regs[12][TILE_SIZE][TILE_SIZE],
	int set_not_increment
) {
	for(int tk = 0; tk < TILE_SIZE; tk++) {
#pragma HLS pipeline II=1
		for(int th = 0; th < 12; th++) {
			for(int ti = 0; ti < TILE_SIZE; ti++) {
				compute_label1:for(int tj = 0; tj < TILE_SIZE; tj++) {
					ap_fixed<16, 10, AP_RND, AP_SAT> mul = (ap_fixed<16, 10, AP_RND, AP_SAT>) (qregs[th][ti][tk] * kregs[th][tk][tj]);
					if(set_not_increment && tk==0)
						out_regs[th][ti][tj] = mul;
					else
						out_regs[th][ti][tj] += mul;
				}
			}
		}
	}
}

void regs_to_bram(
	ap_fixed<16, 10> out_regs[12][TILE_SIZE][TILE_SIZE],
	ap_fixed<8, 6> qk_bram[12][198][198],
	int i, int j
) {
	for(int head = 0; head < 12; head++) {
		for(int ti = 0; ti < TILE_SIZE; ti++) {
			for(int tj = 0; tj < TILE_SIZE; tj++) {
#pragma HLS pipeline II=1
				int hidx = i*TILE_SIZE+ti, widx = j*TILE_SIZE+tj;
				if(hidx < 198 && widx < 198)
					qk_bram[head][hidx][widx] = out_regs[head][ti][tj] / 64;
			}
		}
	}
}

void qk_matmul(
	ap_fixed<8, 5> q_proj_bram[12][198][64],
	ap_fixed<8, 5> k_proj_bram[12][198][64],
	ap_fixed<8, 6> qk_bram[12][198][198]
) {
	ap_fixed<8, 5> qregs[12][TILE_SIZE][TILE_SIZE];
	ap_fixed<8, 5> kregs[12][TILE_SIZE][TILE_SIZE];
	ap_fixed<16, 10> out_regs[12][TILE_SIZE][TILE_SIZE];

#pragma HLS array_partition variable=qregs complete dim=0
#pragma HLS array_partition variable=kregs complete dim=0
#pragma HLS array_partition variable=out_regs complete dim=0

	for(int i = 0; i < 198; i++) {
		for(int j = 0; j < 64; j++) {
			for(int k = 0; k < 64 / TILE_SIZE; k++) {
#pragma HLS dataflow
				bram_to_regs(
					q_proj_bram,
					k_proj_bram,
					qregs,
					kregs,
					i, j, k
				);
				compute(
					qregs,
					kregs,
					out_regs,
					k==0
				);
				regs_to_bram(
					out_regs,
					qk_bram,
					i, j
				);
			}
		}
	}
}
